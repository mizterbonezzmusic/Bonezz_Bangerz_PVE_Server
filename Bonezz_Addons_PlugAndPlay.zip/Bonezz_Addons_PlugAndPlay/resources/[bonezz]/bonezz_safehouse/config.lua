Config = {}
Config.Safehouses = {
    {label="LSPD HQ (Mission Row)", coords=vector3(441.22, -981.94, 30.69)},
    {label="Vespucci Apt", coords=vector3(-1157.45, -1518.78, 10.63)},
    {label="Mirror Park House", coords=vector3(1267.84, -1611.53, 54.73)},
    {label="Sandy Trailer", coords=vector3(1965.12, 3813.45, 32.43)},
    {label="Grapeseed Barn", coords=vector3(2444.18, 4975.29, 46.81)},
    {label="Paleto Cabin", coords=vector3(-402.64, 6191.22, 31.49)},
    {label="El Burro Hideout", coords=vector3(1408.90, -1490.33, 58.62)},
    {label="Del Perro Stash", coords=vector3(-1483.42, -661.71, 29.02)},
    {label="Davis Bungalow", coords=vector3(103.82, -1941.52, 20.80)},
    {label="La Mesa Garage", coords=vector3(733.16, -1063.40, 22.17)}
}

Keep this resource disabled unless you intend to use Bonezz loading screen.

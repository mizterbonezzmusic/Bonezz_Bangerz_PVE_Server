Config = {}
Config.RoamingLEO = {
  {model="s_m_y_cop_01", coords=vector3(441.22, -981.94, 30.69), radius=300.0},
  {model="s_m_m_snowcop_01", coords=vector3(1851.13, 3689.33, 34.26), radius=300.0},
  {model="s_m_y_hwaycop_01", coords=vector3(-443.34, 6027.88, 31.49), radius=300.0}
}

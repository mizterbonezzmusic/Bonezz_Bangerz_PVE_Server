fx_version 'cerulean'
game 'gta5'

name 'bonezz_turfwars'
author 'Bonezz/Auto-Scaffold'
description 'Stub/Scaffold for bonezz_turfwars'
version '0.0.1'

client_scripts {
    'client/*.lua'

}

server_scripts {
    'server/*.lua'

}

shared_script 'config.lua'

print('[chat-minimal] loaded')

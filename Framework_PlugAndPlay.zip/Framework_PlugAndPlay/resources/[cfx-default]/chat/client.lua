RegisterCommand('me', function() end)

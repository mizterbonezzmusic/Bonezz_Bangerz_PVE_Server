fx_version 'cerulean'
game 'gta5'

name 'ox_lib'
author 'Bonezz/Auto-Scaffold'
description 'Stub/Scaffold for ox_lib'
version '0.0.1'

client_scripts {
    'client/*.lua'

}

server_scripts {
    'server/*.lua'

}

shared_script 'config.lua'

fx_version 'cerulean'
game 'gta5'

name 'progressbar'
author 'Bonezz/Auto-Scaffold'
description 'Stub/Scaffold for progressbar'
version '0.0.1'

client_scripts {
    'client/*.lua'

}

server_scripts {
    'server/*.lua'

}

shared_script 'config.lua'
